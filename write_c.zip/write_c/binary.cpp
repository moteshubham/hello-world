#include<iostream>
#include"stdio.h"
using namespace std;

void binarySearch(int arr[],int num,int beg,int end)
{
	int mid=(beg+end)/2;
	
	if(arr[mid]==num)
	{
		cout<<"\nThe number is found at position : "<<mid+1;
		cout<<"\n";
	}
	else if(arr[mid]<num)
	{
		binarySearch(arr,num,mid+1,end);
	}
	else if(arr[mid]>num)
	{
		binarySearch(arr,num,beg,mid);
	}
	else 
	{	cout<<"\nNumber not found.";
		cout<<"\n";
	}
		
}

int main()
{
	int arr[100],n,num,beg,end,mid,temp;
	
	cout<<"\nEnter the Number of elements : ";
	cin>>n;
	
	cout<<"\nEnter the numbers :\n";
	for(int i=0;i<n;i++)
	{
		cin>>arr[i];
	}
	
	cout<<"\nUnsorted numbers : ";
	for(int i=0;i<n;i++)
	{
		cout<<arr[i];
		cout<<"\t";
	}
	
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(arr[i]>arr[j])
			{
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}
	cout<<"\nSorted Array : ";
	for(int i=0;i<n;i++)
	{
		cout<<arr[i];
		cout<<"\t";
	}
	
	beg=0;
	end=n-1;
	cout<<"\nEnter the number you want to find : ";
	cin>>num;
	
	binarySearch(arr,num,beg,end);
	
	
return 0;
}
